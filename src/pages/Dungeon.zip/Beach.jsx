import React, { useEffect, useState, useRef } from "react";
import "./Gameplay.css";
import "./Beach.css";
import beachMap from "../assets/map/Beach.jpg";
import coconutTreeImg from "../assets/map-assets/Beach/Beach_tree_with_coconut.png";
import coconutVideo from "../assets/map-assets/Beach/coconut_fall_animation.mp4";
import coconutIcon from "../assets/inventory-items/Coconut.png";
import rockBg1 from "../assets/map-assets/Beach/Rock_minigame1.jpg";
import rockBg2 from "../assets/map-assets/Beach/Rock_minigame2.jpg";
import rockBg3 from "../assets/map-assets/Beach/Rock_minigame3.jpg";
import rockBg4 from "../assets/map-assets/Beach/Rock_minigame4.jpg";
import pickaxeImg from "../assets/map-assets/Beach/Beach_pickaxe.png";
import arrowUp from "../assets/ui/ArrowUP.png";
import arrowDown from "../assets/ui/ArrowDOWN.png";
import arrowLeft from "../assets/ui/ArrowLEFT.png";
import arrowRight from "../assets/ui/ArrowRIGHT.png";
import ancientGlassImg from "../assets/inventory-items/AncientGlass.png";
import hungryIcon from "../assets/inventory-items/Hunger.png";
import sleepIcon from "../assets/inventory-items/Sleep.png";
import happyIcon from "../assets/inventory-items/Happiness.png";
import cleanIcon from "../assets/inventory-items/Cleanliness.png";
import coinGif from "../assets/ui/MoneyMoney.gif";

import scrollBanner from "../assets/ui/ScrollObtainedItem.png";


const MAP_WIDTH = 1384;
const MAP_HEIGHT = 1039;
const SPRITE_SIZE = 64;

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export default function Beach() {
  const [status, setStatus] = useState({ meal: 50, sleep: 50, happiness: 50, cleanliness: 50 });
  const [money, setMoney] = useState(0);
  const [inventory, setInventory] = useState([]);
  const [inventoryVisible, setInventoryVisible] = useState(false);
  const [username, setUsername] = useState("Player");
  const [currentMinute, setCurrentMinute] = useState(0);
  const [currentHour, setCurrentHour] = useState(9);
  const [currentDayIndex, setCurrentDayIndex] = useState(0);
  const [position, setPosition] = useState({ x: MAP_WIDTH / 2 - SPRITE_SIZE / 2, y: MAP_HEIGHT - SPRITE_SIZE });
  const [character, setCharacter] = useState(null);
  const [direction, setDirection] = useState("down");
  const [isMoving, setIsMoving] = useState(false);

  const [nearExitZone, setNearExitZone] = useState(false);
  const [inCoconutZone, setInCoconutZone] = useState(false);
  const [inSunbatheZone, setInSunbatheZone] = useState(false);
  const [isSunbathing, setIsSunbathing] = useState(false);
  const [skipRequested, setSkipRequested] = useState(false);

  const [showCoconutGame, setShowCoconutGame] = useState(false);
  const [showCoconutVideo, setShowCoconutVideo] = useState(false);
  const [showCoconutResult, setShowCoconutResult] = useState(false);

  const [inRockZone, setInRockZone] = useState(false);
  const [showRockMinigame, setShowRockMinigame] = useState(false);
  const [progress, setProgress] = useState(0);
  const [gameStage, setGameStage] = useState(1); // 1 = awal, 2 = menengah, 3 = sulit
  const [levelCleared, setLevelCleared] = useState(false); // ✅ buat transisi
  const [levelUp, setLevelUp] = useState(false);
  const [isEndingRockGame, setIsEndingRockGame] = useState(false);
  const [fadeOverlay, setFadeOverlay] = useState(false);

  const [pointerX, setPointerX] = useState(0); // posisi pointer 0–100
  const [targetX, setTargetX] = useState(() => Math.random() * 80 + 10); // posisi target acak di tengah
  const [isPointerFrozen, setIsPointerFrozen] = useState(false);
  const [pickaxeSwinging, setPickaxeSwinging] = useState(false);

  const [glassPos, setGlassPos] = useState(null);
  const [nearGlass, setNearGlass] = useState(false);
  const [showGlassResult, setShowGlassResult] = useState(false);


  const isInRestrictedZone = (x, y) => {
    // coconut
    if (x >= 100 && x <= 300 && y >= 650 && y <= 850) return true;
    // rock
    if (x >= 1000 && x <= 1430 && y >= 380 && y <= 710) return true;
    // water
    if (y >= 0 && y <= 170) return true;
    // exit zone
    if (y >= MAP_HEIGHT - SPRITE_SIZE) return true;
    return false;
  };

  const generateGlassPos = () => {
    let x, y;
    do {
      x = Math.floor(Math.random() * (MAP_WIDTH - SPRITE_SIZE));
      y = Math.floor(Math.random() * (MAP_HEIGHT - SPRITE_SIZE));
    } while (isInRestrictedZone(x, y));
    return { x, y };
  };



  const getRockFrame = () => {
    if (gameStage === 1) return rockBg1;
    if (gameStage === 2) return rockBg2;
    if (gameStage === 3) return rockBg3;
    return rockBg4; // final
  };

  const keysPressed = useRef({});

  const isInWater = (x, y) => {
    return y >= 0 && y <= 170;
  };

  useEffect(() => {
    const savedChar = JSON.parse(localStorage.getItem("selectedCharacter"));
    if (savedChar) setCharacter(savedChar);

    const savedData = JSON.parse(localStorage.getItem("playerData"));
    if (savedData) {
      setStatus(savedData.status || {});
      setMoney(savedData.money || 0);
      setInventory(savedData.inventory || []);
    }

    setUsername(localStorage.getItem("playerName") || "Player");

    const savedTime = JSON.parse(localStorage.getItem("playerTime"));
    if (savedTime) {
      setCurrentMinute(savedTime.savedMinute);
      setCurrentHour(savedTime.savedHour);
      setCurrentDayIndex(savedTime.savedDay);
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMinute(prev => {
        let newMinute = prev + 1;
        setCurrentHour(prevHour => {
          let hour = prevHour;
          let day = currentDayIndex;

          if (newMinute >= 60) {
            newMinute = 0;
            hour += 1;
            setStatus(prev => {
              const newStatus = { ...prev };
              for (let key in newStatus) newStatus[key] = Math.max(newStatus[key] - 2, 0);
              if (Object.values(newStatus).every(val => val === 0)) window.location.href = "/ending";
              return newStatus;
            });
          }

          if (hour >= 24) {
            hour = 0;
            day = (day + 1) % 7;
            setCurrentDayIndex(day);
          }

          return hour;
        });
        return newMinute >= 60 ? 0 : newMinute;
      });
    }, 250);

    return () => clearInterval(interval);
  }, [currentDayIndex]);

  useEffect(() => {
    let animationId

    const isInRockZone = (x, y) => {
      return x >= 1000 && x <= 1430 && y >= 380 && y <= 710;
    };

    ;
    const update = () => {
      if (isSunbathing) return;

      setPosition(prev => {
        const newPos = { ...prev };
        let moved = false;

        if (keysPressed.current.w || keysPressed.current.arrowup) {
          newPos.y = Math.max(newPos.y - 2, 0);
          setDirection("up");
          moved = true;
        }
        if (keysPressed.current.s || keysPressed.current.arrowdown) {
          newPos.y = Math.min(newPos.y + 2, MAP_HEIGHT - SPRITE_SIZE);
          setDirection("down");
          moved = true;
        }
        if (keysPressed.current.a || keysPressed.current.arrowleft) {
          newPos.x = Math.max(newPos.x - 2, 0);
          setDirection("left");
          moved = true;
        }
        if (keysPressed.current.d || keysPressed.current.arrowright) {
          newPos.x = Math.min(newPos.x + 2, MAP_WIDTH - SPRITE_SIZE);
          setDirection("right");
          moved = true;
        }

        // ⛏️ Deteksi dulu status rock zone agar tetap bisa set state meski karakter tidak masuk
        const rockStatus = isInRockZone(newPos.x, newPos.y);
        setInRockZone(rockStatus);
        
        if (glassPos) {
          const near = Math.abs(glassPos.x - newPos.x) < 40 && Math.abs(glassPos.y - newPos.y) < 40;
          setNearGlass(near);
        }

        if (isInWater(newPos.x, newPos.y)) return prev;
        if (rockStatus) return prev;


        if (isInWater(newPos.x, newPos.y)) return prev;
        if (rockStatus) return prev;

        setIsMoving(moved);
        setNearExitZone(newPos.y >= MAP_HEIGHT - SPRITE_SIZE);
        setInCoconutZone(
          newPos.x >= 100 && newPos.x <= 300 &&
          newPos.y >= 650 && newPos.y <= 850
        );
        setInSunbatheZone(
          newPos.x >= 750 && newPos.x <= 900 &&
          newPos.y >= 240 && newPos.y <= 380
        );

        if (glassPos) {
          const near = Math.abs(glassPos.x - newPos.x) < 40 && Math.abs(glassPos.y - newPos.y) < 40;
          setNearGlass(near);
        }


        return newPos;
      });

      animationId = requestAnimationFrame(update);
    };



    const handleKeyDown = (e) => { keysPressed.current[e.key.toLowerCase()] = true; };
    const handleKeyUp = (e) => { keysPressed.current[e.key.toLowerCase()] = false; };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    animationId = requestAnimationFrame(update);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
      cancelAnimationFrame(animationId);
    };
  }, [isSunbathing]);

  useEffect(() => {
    const x = position.x;
    const y = position.y;
    const sprite = SPRITE_SIZE;

    const inRock =
      x + sprite > 1000 &&
      x < 1430 &&
      y + sprite > 380 &&
      y < 710;

    setInRockZone(inRock);
  }, [position]);

 const pointerDir = useRef(1); // arah pointer tetap terjaga (1 = kanan, -1 = kiri)

useEffect(() => {
  if (!showRockMinigame) return;

  const speed = gameStage === 1 ? 1 : gameStage === 2 ? 1.8 : 2.5;

  const interval = setInterval(() => {
    if (!isPointerFrozen) {
      setPointerX(prev => {
        let next = prev + pointerDir.current * speed;

        if (next >= 100 || next <= 0) {
          pointerDir.current *= -1; // ganti arah
          next = Math.max(0, Math.min(100, next));
        }

        return next;
      });
    }
  }, 16);

  return () => clearInterval(interval);
}, [showRockMinigame, gameStage, isPointerFrozen]);



  useEffect(() => {
    if (!levelCleared) return;

    if (gameStage < 3) {
      setGameStage(prev => prev + 1);
      setPointerX(0);
      setTargetX(Math.random() * 80 + 10);
      setLevelCleared(false);
    } else {
      setGameStage(4); // tampilkan frame pecah
      setTimeout(() => {
        setFadeOverlay(true); // ⬅️ fade out
        setTimeout(() => {
          setShowRockMinigame(false);
          setInventory(prev => [...prev, "Rusty Iron"]);
          setGameStage(1);
          setPointerX(0);
          setTargetX(Math.random() * 80 + 10);
          setFadeOverlay(false); // reset overlay
          setLevelCleared(false);
        }, 1000); // ⬅️ waktu fade hitam sebelum balik
      }, 2000); // ⬅️ waktu tampil frame 4
    }

  }, [levelCleared]);

  useEffect(() => {
    const hasGlass = inventory.includes("Ancient Glass");
    if (!hasGlass) {
      setGlassPos(generateGlassPos());
    }
  }, [inventory]);


  const getEventText = () => {
    if (nearGlass) return "🍶 Press Interact to collect Ancient Glass";
    if (inSunbatheZone) return "🌞 Press Interact to sunbathe";
    if (inCoconutZone) return "🥥 Press Interact to shake the coconut tree";
    if (inRockZone) return "⛏️ Press Interact to mine the rock";
    if (nearExitZone) return "🔙 Press Interact to return to the main map";
    return "📍 Event info will appear here...";
  };


  const handleInteract = () => {

    if (nearGlass && glassPos) {
      setInventory(prev => {
        const updated = [...prev, "Ancient Glass"];
        localStorage.setItem("playerData", JSON.stringify({
          status,
          money,
          inventory: updated,
          character,
          position
        }));
        return updated;
      });
      setGlassPos(null); // hapus dari map
      setShowGlassResult(true); // ⬅️ tampilkan banner
      return;
    }

    if (inSunbatheZone) {
      setIsSunbathing(true);
      setSkipRequested(false);
      const isLeft = position.x < 825;
      const targetX = isLeft ? 765 : 830;
      const targetY = 290;
      setPosition({ x: targetX, y: targetY });

      // Reset skip
      let tick = 0;
      const cleanlinessStep = 20 / 5; // 4% per detik
      const timeStep = 60 / 5; // 12 menit per detik

      const interval = setInterval(() => {
        if (skipRequested || tick >= 5) {
          // Langsung selesaikan
          setStatus(prev => ({
            ...prev,
            cleanliness: Math.max(prev.cleanliness - 20, 0)
          }));
          setCurrentMinute(min => {
            const total = currentHour * 60 + min + 60;
            setCurrentHour(Math.floor((total % 1440) / 60));
            setCurrentDayIndex((currentDayIndex + Math.floor(total / 1440)) % 7);
            return total % 60;
          });
          setIsSunbathing(false);
          clearInterval(interval);
          return;
        }

        // Perlahan turunkan cleanliness dan naikan waktu
        setStatus(prev => ({
          ...prev,
          cleanliness: Math.max(prev.cleanliness - cleanlinessStep, 0)
        }));
        setCurrentMinute(min => {
          let total = currentHour * 60 + min + timeStep;
          setCurrentHour(Math.floor((total % 1440) / 60));
          setCurrentDayIndex((currentDayIndex + Math.floor(total / 1440)) % 7);
          return total % 60;
        });

        tick++;
      }, 1000);
    }

    if (inCoconutZone) {
      setShowCoconutGame(true); // munculin gambar pertama
      return;
    }

    if (inRockZone) {
      setFadeOverlay(true); // ⬅️ aktifkan overlay
      setTimeout(() => {
        setProgress(0);
        setPointerX(0);
        setTargetX(Math.random() * 80 + 10);
        setShowRockMinigame(true);
        setFadeOverlay(false); // ⬅️ hilangkan setelah masuk
      }, 800); // durasi fade
      return;
    }

    if (nearExitZone) {
      const saved = JSON.parse(localStorage.getItem("playerData")) || {};
      localStorage.setItem("playerData", JSON.stringify({
        ...saved,
        status,
        money,
        inventory
      }));
      localStorage.setItem("playerTime", JSON.stringify({
        startTimestamp: Date.now(),
        savedMinute: currentMinute,
        savedHour: currentHour,
        savedDay: currentDayIndex
      }));
      window.location.href = "/gameplay";
    }


      };

  const getSpriteOffset = () => {
    if (isSunbathing) return "0px 0px";
    const directionMap = { down: 0, left: 1, right: 2, up: 3 };
    const row = directionMap[direction];
    const col = isMoving ? Math.floor(Date.now() / 150) % 4 : 1;
    return `-${col * SPRITE_SIZE}px -${row * SPRITE_SIZE}px`;
  };

  const offsetX = Math.min(Math.max(-position.x + window.innerWidth / 2, -(MAP_WIDTH - window.innerWidth)), 0);
  const offsetY = Math.min(Math.max(-position.y + window.innerHeight / 2, -(MAP_HEIGHT - window.innerHeight)), 0);

  const handleAnalog = (key, value) => {
    if (!isSunbathing) keysPressed.current[key] = value;
  };

  const formatTime = (h, m) => `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;

  return (
    <div className="viewport">
      {/* Coconut Minigame UI */}
      {showCoconutGame && (
        <div className="coconut-overlay" onClick={() => {
          setShowCoconutGame(false);
          setShowCoconutVideo(true);
        }}>
          <img src={coconutTreeImg} alt="Tree POV" className="coconut-image" />
          <div className="tap-text">Tap the coconut</div>
        </div>
      )}

      {showGlassResult && (
        <div className="coconut-overlay result">
          <div
            className="obtained-banner"
            style={{ backgroundImage: `url(${scrollBanner})` }}
          >
            <div className="obtained-text">You have obtained</div>
            <img src={ancientGlassImg} alt="Ancient Glass" className="coconut-icon" />
            <div className="item-name">Ancient Glass</div>
            <button className="ok-button" onClick={() => setShowGlassResult(false)}>OK</button>
          </div>
        </div>
      )}

      {showCoconutVideo && (
        <div className="coconut-overlay">
          <video
            src={coconutVideo}
            autoPlay
            onEnded={() => {
              setShowCoconutVideo(false);
              setShowCoconutResult(true);
              setInventory(prev => {
              const updated = [...prev, "Rusty Iron"];
              localStorage.setItem("playerData", JSON.stringify({
                status,
                money,
                inventory: updated,
                character,
                position
              }));
              return updated;
            });

            }}
            className="coconut-video"
          />
        </div>
      )}

      {showCoconutResult && (
        <div className="coconut-overlay result">
          <div
            className="obtained-banner"
            style={{ backgroundImage: `url(${scrollBanner})` }}
          >
            <div className="obtained-text">You have obtained</div>
            <img src={coconutIcon} alt="Coconut" className="coconut-icon" />
            <div className="item-name">Coconut</div>
            <button className="ok-button" onClick={() => setShowCoconutResult(false)}>OK</button>
          </div>
        </div>
      )}

  {showRockMinigame && (
  <div
    className="rock-minigame-overlay"
    onClick={() => {
      if (gameStage === 4 || isPointerFrozen) return;

      setIsPointerFrozen(true); // ❄️ pointer stop
      setPickaxeSwinging(true); // ⛏️ animasi

      setTimeout(() => setPickaxeSwinging(false), 1000); // hanya 1x ayun
const hitWidth = 15; // atau 8, atau nilai sesuai width bar kamu
const inZone = pointerX >= targetX && pointerX <= targetX + hitWidth;


      setTimeout(() => {
        if (inZone) {
          setLevelCleared(true); // ⏫ lanjut stage
        }
        setIsPointerFrozen(false); // pointer jalan lagi (kalau gagal)
      }, 500);
    }}
  >
    <img src={getRockFrame()} alt="Rock Minigame" className="rock-minigame-background" />

    <img
  src={pickaxeImg}
  alt="Pickaxe"
  className={`rock-pickaxe ${pickaxeSwinging ? 'active' : ''}`}
/>

{gameStage !== 4 && (
  <>
    <div className="rock-bar-container">
      <div
        className="rock-target-zone"
        style={{
          left: `${targetX}%`,
          width: "8%",
        }}
      ></div>

      <div className="rock-moving-pointer" style={{ left: `${pointerX}%` }}></div>
    </div>

    <div className="rock-hit-zone"></div>

    <div className="rock-minigame-bar">
      <div
        className="rock-minigame-bar-fill"
        style={{ width: `${progress}%` }}
      ></div>
    </div>
  </>
)}

  </div>
)}


    {fadeOverlay && (
      <div className="fade-black"></div>
    )}


      <div className="time-display">
        <div className="clock-text">{days[currentDayIndex]}, {formatTime(currentHour, currentMinute)}</div>
      </div>

      <div className="map" style={{
        backgroundImage: `url(${beachMap})`,
        left: `${offsetX}px`,
        top: `${offsetY}px`,
        width: `${MAP_WIDTH}px`,
        height: `${MAP_HEIGHT}px`,
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "top left",
        position: "absolute"
      }}>
        {character && (
          <div
            className="character"
            style={{
              left: position.x,
              top: position.y,
              backgroundImage: `url(${character.sprite})`,
              backgroundPosition: getSpriteOffset(),
              transform: isSunbathing ? "rotate(180deg)" : "none"
            }}
          ></div>
        )}

        {glassPos && (
          <>
            <img
              src={ancientGlassImg}
              alt="Ancient Glass"
              style={{
                position: "absolute",
                left: glassPos.x,
                top: glassPos.y,
                width: 32,
                height: 32,
                zIndex: 4
              }}
            />
            {/* Tambahkan visualisasi hitbox */}
            <div
              className="glass-hitbox"
              style={{
                left: glassPos.x - 4,
                top: glassPos.y - 4
              }}
            ></div>
          </>
        )}

        
        <div className="exit-gradient-zone"></div>

        <div className="water-zone"></div>
        <div className="sunbathe-zone"></div>
        <div className="coconut-zone"></div>
        <div className="rock-zone"></div>
        
      </div>

      <div className="status-ui">
        <div className="status-left">
          <div className="greeting-ui">Welcome back, {username}</div>
          <div className="status-bars">
                <div className="status-item">
                  <img src={hungryIcon} alt="Meal" className="status-icon" />
                  <div className="bar"><div style={{ width: `${status.meal}%` }}></div></div>
                </div>
                <div className="status-item">
                  <img src={sleepIcon} alt="Sleep" className="status-icon" />
                  <div className="bar"><div style={{ width: `${status.sleep}%` }}></div></div>
                </div>
                <div className="status-item">
                  <img src={happyIcon} alt="Happiness" className="status-icon" />
                  <div className="bar"><div style={{ width: `${status.happiness}%` }}></div></div>
                </div>
                <div className="status-item">
                  <img src={cleanIcon} alt="Cleanliness" className="status-icon" />
                  <div className="bar"><div style={{ width: `${status.cleanliness}%` }}></div></div>
                </div>
              </div>
        </div>

        <div className="status-money">
          <div className="money">
            {money}
            <img src={coinGif} alt="Gold" className="coin-icon" />
          </div>
          <button className="inventory-btn" onClick={() => setInventoryVisible(prev => !prev)}>Inventory</button>
          {inventoryVisible && (
            <div className="inventory-modal">
              <div className="inventory-grid">
                {Array.from({ length: 50 }).map((_, i) => (
                  <div key={i} className="inventory-slot">
                    {inventory[i] ? (
                      <div className="inventory-item">{inventory[i]}</div>
                    ) : null}
                  </div>
                ))}
              </div>
              <button
                className="close-inventory-btn"
                onClick={() => setInventoryVisible(false)}
              >
                Close
              </button>
            </div>
          )}

        </div>
      </div>

      <div className="analog-controls">
      <button
        className="arrow up"
        onMouseDown={() => handleAnalog("arrowup", true)}
        onMouseUp={() => handleAnalog("arrowup", false)}
      >
        <img src={arrowUp} alt="Up" className="arrow-img" />
      </button>

      <div className="horizontal">
        <button
          className="arrow left"
          onMouseDown={() => handleAnalog("arrowleft", true)}
          onMouseUp={() => handleAnalog("arrowleft", false)}
        >
          <img src={arrowLeft} alt="Left" className="arrow-img" />
        </button>

        <button
          className="arrow right"
          onMouseDown={() => handleAnalog("arrowright", true)}
          onMouseUp={() => handleAnalog("arrowright", false)}
        >
          <img src={arrowRight} alt="Right" className="arrow-img" />
        </button>
      </div>

      <button
        className="arrow down"
        onMouseDown={() => handleAnalog("arrowdown", true)}
        onMouseUp={() => handleAnalog("arrowdown", false)}
      >
        <img src={arrowDown} alt="Down" className="arrow-img" />
      </button>
    </div>


      <div className="event-panel">
        <p className="event-text">{getEventText()}</p>
        <button className="event-button" onClick={handleInteract}>Interact</button>
      </div>
    </div>
  );
}
